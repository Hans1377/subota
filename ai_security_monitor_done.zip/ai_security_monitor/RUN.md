# Как запустить лабу позже

```bash
cd ai_security_monitor
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt

python scripts/generate_network_data.py   # сетевые данные (синтетика)
python scripts/generate_text_data.py      # текстовый датасет (синтетика, без интернета)
python train_all.py                       # обучение + метрики + события
pytest -q                                 # тесты (включая ложные срабатывания)
streamlit run app.py                      # панель: http://127.0.0.1:8501
```
Готовые данные, модели и отчёты уже лежат в `data/`, `models/`, `outputs/`,
поэтому можно сразу сделать `pip install` и `streamlit run app.py`.
Для реального датасета используйте `scripts/prepare_text_dataset.py` (см. README).
